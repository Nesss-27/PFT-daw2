'use client';
import { useState, ReactNode } from "react";
import Menu from "@/components/ui/menu";
import Button from "@/components/buttom";
import Bactest from "@/components/backtest/grafico";

interface BotonMenuProps {
    id: string;
    children: ReactNode;
}

export default function Page() {
    const [seleccionado, setSeleccionado] = useState<string | null>(null);

    const BotonMenu = ({ id, children }: BotonMenuProps) => (
        <Button 
            id={id} 
            seleccionado={seleccionado === id} 
            onClick={() => setSeleccionado(id)}
        >
            {children}
        </Button>
    );

    return (
        <>
        <Menu titulo="Menu" xmen={1} ymen={1}>
            <BotonMenu id="btn-1">Usuario</BotonMenu>
            <BotonMenu id="btn-2">Backtest</BotonMenu>
            <BotonMenu id="btn-3">Screener</BotonMenu>
            <BotonMenu id="btn-4">Salir</BotonMenu>
        </Menu>

        {seleccionado === "btn-1" && <Menu xmen={165} ymen={1} titulo="Usuario">
            <BotonMenu id="btn-5">Ajustes</BotonMenu>
        </Menu>}
        {seleccionado === "btn-2" && <Menu titulo="Backtest" xmen={165} ymen={1}> <Bactest></Bactest> </Menu>}
        </>
    );
}