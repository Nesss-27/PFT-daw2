'use client';

export default function Page() {
 
     return (
        <div className="w-50 h-50 bg-black">
            
        </div>
     )
}